import Home from "./components/Home";
import Restaurant from "./components/Restaurant";
import Search from "./components/Search";
import { Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";


function App() {

  let [locationList, setLocationList] = useState([]);

  let getLocationList = async () => {
    try {
      let url = "http://localhost:3001/api/get-location-list";
      let { data } = await axios.get(url);
      setLocationList(data.locationList); // updating locationList
    } catch (error) {
      alert("SERVER ERROR");
    }
  };


  useEffect(() => {
    getLocationList();
    // mounting
  }, []);

  return (
    <>
      <Routes>
        <Route path="/" element={<Home locationList={locationList} />} />
        <Route path="/search/:id/:name" element={<Search locationList={locationList} />} />
        {/* <Route path="/restaurant/" element={<Restaurant locationList={locationList} />} /> */}
        <Route path="/restaurant/:id" element={<Restaurant locationList={locationList} />} />
      </Routes>

    </>

  );
}

export default App;
